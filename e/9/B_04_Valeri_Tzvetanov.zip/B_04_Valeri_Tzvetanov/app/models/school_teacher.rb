class SchoolTeacher < ActiveRecord::Base
	belongs_to :teacher
	belongs_to :school
	
	vaidate do
	if Teacher.find(teacher_id).name.length != School.find(school_id).number
    	errors.add(:name, "Cannot add that teacher")
	end
	end
end
