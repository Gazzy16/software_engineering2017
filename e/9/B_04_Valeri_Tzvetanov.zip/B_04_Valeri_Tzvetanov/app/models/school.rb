class School < ActiveRecord::Base
	has_many :school_teachers
	has_many :schools, through: :school_teachers
end
