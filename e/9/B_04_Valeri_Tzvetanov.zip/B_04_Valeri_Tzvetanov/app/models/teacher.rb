class Teacher < ActiveRecord::Base
	has_many :school_teachers
	has_many :teachers, through: :school_teachers

	validates :first_name, uniqueness: { scope: :second_name,
	message: "there is another teacher with this name already" }

end
