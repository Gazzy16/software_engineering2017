require 'test_helper'

class SchoolTeacherTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
