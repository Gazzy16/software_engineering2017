class CreateSchools < ActiveRecord::Migration
  def change
    create_table :schools do |t|
      t.string :school_name
      t.integer :school_num

      t.timestamps null: false
    end
  end
end
