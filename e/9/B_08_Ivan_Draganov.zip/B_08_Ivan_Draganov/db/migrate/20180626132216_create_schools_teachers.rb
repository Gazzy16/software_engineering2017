class CreateSchoolsTeachers < ActiveRecord::Migration
  def change
    create_table :schools_teachers do |t|
      t.references :school
      t.references :teacher

      t.timestamps null: false
    end
  end
end
