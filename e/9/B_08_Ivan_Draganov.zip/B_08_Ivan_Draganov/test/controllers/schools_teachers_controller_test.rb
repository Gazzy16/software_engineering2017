require 'test_helper'

class SchoolsTeachersControllerTest < ActionController::TestCase
  setup do
    @schools_teacher = schools_teachers(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:schools_teachers)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create schools_teacher" do
    assert_difference('SchoolsTeacher.count') do
      post :create, schools_teacher: { school: @schools_teacher.school, teacher: @schools_teacher.teacher }
    end

    assert_redirected_to schools_teacher_path(assigns(:schools_teacher))
  end

  test "should show schools_teacher" do
    get :show, id: @schools_teacher
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @schools_teacher
    assert_response :success
  end

  test "should update schools_teacher" do
    patch :update, id: @schools_teacher, schools_teacher: { school: @schools_teacher.school, teacher: @schools_teacher.teacher }
    assert_redirected_to schools_teacher_path(assigns(:schools_teacher))
  end

  test "should destroy schools_teacher" do
    assert_difference('SchoolsTeacher.count', -1) do
      delete :destroy, id: @schools_teacher
    end

    assert_redirected_to schools_teachers_path
  end
end
