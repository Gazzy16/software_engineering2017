require 'test_helper'

class SchoolsTeacherTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
