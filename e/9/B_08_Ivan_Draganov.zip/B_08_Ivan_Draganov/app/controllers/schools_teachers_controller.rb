class SchoolsTeachersController < ApplicationController
  before_action :set_schools_teacher, only: [:show, :edit, :update, :destroy]

  # GET /schools_teachers
  # GET /schools_teachers.json
  def index
    @schools_teachers = SchoolsTeacher.all
	@schools = School.all
	    @teachers = Teacher.all
  end

  # GET /schools_teachers/1
  # GET /schools_teachers/1.json
  def show
  end

  # GET /schools_teachers/new
  def new
    @schools_teacher = SchoolsTeacher.new
  end

  # GET /schools_teachers/1/edit
  def edit
  end

  # POST /schools_teachers
  # POST /schools_teachers.json
  def create
    @schools_teacher = SchoolsTeacher.new(schools_teacher_params)

    respond_to do |format|
      if @schools_teacher.save
        format.html { redirect_to @schools_teacher, notice: 'Schools teacher was successfully created.' }
        format.json { render :show, status: :created, location: @schools_teacher }
      else
        format.html { render :new }
        format.json { render json: @schools_teacher.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /schools_teachers/1
  # PATCH/PUT /schools_teachers/1.json
  def update
    respond_to do |format|
      if @schools_teacher.update(schools_teacher_params)
        format.html { redirect_to @schools_teacher, notice: 'Schools teacher was successfully updated.' }
        format.json { render :show, status: :ok, location: @schools_teacher }
      else
        format.html { render :edit }
        format.json { render json: @schools_teacher.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /schools_teachers/1
  # DELETE /schools_teachers/1.json
  def destroy
    @schools_teacher.destroy
    respond_to do |format|
      format.html { redirect_to schools_teachers_url, notice: 'Schools teacher was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_schools_teacher
      @schools_teacher = SchoolsTeacher.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def schools_teacher_params
      params.require(:schools_teacher).permit(:school, :teacher)
    end
end
