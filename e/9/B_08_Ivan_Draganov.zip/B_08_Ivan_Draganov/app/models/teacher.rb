class Teacher < ActiveRecord::Base
	has_many :schools_teachers
	has_many :schools through: :schools_teachers
	validate :samenames
end

private 

	def samenames
		count = Teacher.where(first_name :Self.first_name,last_name:Self.last_name).count
		if(count > 1)
				errors.add(:base,"err")
		end
	end
