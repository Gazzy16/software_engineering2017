class School < ActiveRecord::Base
	has_many :schools_teachers
	has_many :teachers through: :schools_teachers

end


