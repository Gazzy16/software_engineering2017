class SchoolsTeacher < ActiveRecord::Base
	belongs_to :teacher
	belongs_to :school
	validate :canteach
end

private 
	def canteach
		    TeacherSchool.where(school_id: school_id).each do |ts|
				 if ts.school.school_num == Teacher.find(teacher_id).first_name.length 
       				errors.add(:base,"err")
     			 end
			end
	end 
