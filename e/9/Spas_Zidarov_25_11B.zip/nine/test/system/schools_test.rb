require "application_system_test_case"

class SchoolsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit schools_url
  #
  #   assert_selector "h1", text: "School"
  # end
end
