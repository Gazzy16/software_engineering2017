require "application_system_test_case"

class TeachersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit teachers_url
  #
  #   assert_selector "h1", text: "Teacher"
  # end
end
