require "application_system_test_case"

class ConnectionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit connections_url
  #
  #   assert_selector "h1", text: "Connection"
  # end
end
