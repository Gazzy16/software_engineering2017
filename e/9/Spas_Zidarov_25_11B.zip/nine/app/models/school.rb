class School < ApplicationRecord
	has_many :connections
	has_many :teachers, through: :connections 
end
