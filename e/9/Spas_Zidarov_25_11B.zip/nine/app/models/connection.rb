class Connection < ApplicationRecord
	belongs_to :teachers
	belongs_to :schools

	validate do 
		if has_first_name? School.find(self.school_id).first_name
				errors.add(:team, "There is already a teacher with this first name")
		end
	end

	validate do 
		if has_last_name? School.find(self.school_id).last_name
				errors.add(:school, "There is already a teacher with this last name")
		end
	end

	private
		def has_first_name? first_name
		Connections.where(teacher_id: self.teacher_id).each do |mt|
			if first_name==School.find(mt.school_id).first_name
				return true
			end
		end
		false
	end

	private
		def has_last_name? last_name
		Connections.where(teacher_id: self.teacher_id).each do |mt|
			if last_name==School.find(mt.school_id).last_name
				return true
			end
		end
		false
	end
end
